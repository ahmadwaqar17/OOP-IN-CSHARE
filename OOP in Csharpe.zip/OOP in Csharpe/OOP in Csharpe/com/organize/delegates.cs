﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
public delegate int add(int x, int y);
namespace OOP_in_Csharpe.com.organize
{
    class delegates
    {
        
    }
}
