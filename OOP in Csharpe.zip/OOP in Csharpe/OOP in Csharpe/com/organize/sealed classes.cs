﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
sealed class sp {
    public sp()
    {
        Console.WriteLine("this is sealed class");

    }
}
    /*class sc:sp
{
    public sc()
    {
        Console.WriteLine("i can't inherit sealed class");

    }
}
    */
namespace OOP_in_Csharpe.com.organize
{
    class sealed_classes
    {
    }
}
